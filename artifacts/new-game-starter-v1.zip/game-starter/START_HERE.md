# 기본 뼈대 시작하기

이 압축 파일은 게임 개발 전 문서·작업 절차·스킬·구조 검사를 준비한다. Python 3.9 이상만 필요하며 엔진·플러그인 설치가 필요하지 않다. 게임 코드는 포함하지 않는다.

## 사용 순서

1. 새 빈 폴더에 압축을 푼다. 숨김 폴더 `.agents`도 함께 풀어야 한다.
2. 이 폴더를 Codex에서 열고 아래 요청문을 전달한다.
3. `project-input.json`에 확인한 입력을 작성한다. 모르는 엔진·화면·플랫폼은 null 또는 빈 목록을 유지한다.
4. 중요한 값과 사용자의 답변을 확인한 뒤 `confirmed`를 true로 바꾸고 `python3 tools/configure_project.py`를 실행한다.
5. `python3 tools/verify_bootstrap.py --scope all --require-configured`를 실행하고 실제 결과를 `_workspace/bootstrap/04_closeout.md`에 남긴다.

macOS·Linux에서는 `./scripts/verify.sh`도 사용할 수 있다. ZIP을 푸는 도구가 실행 권한을 보존하지 않았다면 `sh scripts/verify.sh`를 사용한다. Windows에서는 Python 명령을 사용한다.

입력 전의 `python3 tools/verify_bootstrap.py --scope all` 통과는 뼈대가 준비됐다는 뜻이다. 게임별 입력 적용 완료와 게임 실행 완료는 별도다.

## Codex 시작 요청문

```text
이 폴더의 START_HERE.md와 docs/operations/new-game-bootstrap.md를 따라 게임 개발 준비를 완료해 주세요.
기존 파일과 지시를 먼저 확인하고 중요한 누락은 한 번에 묶어서 질문해 주세요.
이름·ID·핵심 플레이·첫 목표를 확인한 뒤 project-input.json에 기록하고 configure_project.py를 실행해 주세요.
나머지 미정은 제안으로 유지하고 --require-configured 구조 검사 결과를 마무리 기록에 남겨 주세요.
게임 코드, 도구 설치, 계정 연결, Git 원격 변경은 이번 준비에 포함하지 않습니다.
```

## 입력과 재실행

- 필수: game_name(이름), project_id(소문자 영문·숫자·하이픈), core_play(핵심 플레이), first_goal(첫 목표), confirmed(사용자 확인).
- 선택: platforms(목록), engine(이름 또는 null), screen_input(한 줄 또는 null), excluded_features(목록), optional_tools(목록), android(true/false).
- Godot 문서를 활성화하려면 engine을 `godot`으로 쓴다. Android 확인 계획을 활성화하려면 android를 true로 쓴다. 서로 독립적으로 선택할 수 있다.
- 같은 입력으로 다시 실행하면 파일을 변경하지 않는다. 설정 뒤 입력을 바꾸면 자동 적용을 중단한다. 바뀐 요구는 결정 기록과 관련 문서를 보존하며 수동으로 반영하고 bootstrap-state.json의 applied_input도 실제 승인 입력에 맞춘다.
- 설정 전에 문서가 이미 수정됐다면 도구는 덮어쓰지 않는다. 기존 변경을 보존하며 지침서에 따라 수동으로 구성한다. 수동 구성 시 bootstrap-state.json의 상태·이름·ID·선택 항목·applied_input을 실제 입력과 일치시키고 template_hashes는 제거한다.

## 기존 프로젝트에 사용할 때

압축을 기존 프로젝트 위에 바로 풀지 않는다. 별도 빈 폴더에 풀고 지침서의 기존 프로젝트 절차에 따라 필요한 문서·스킬·검사만 비교해 보완한다. 기존 문서·코드·결정·검사 명령을 덮어쓰지 않는다. configure_project.py는 이 뼈대의 최초 설정 도구이며 기존 저장소에 강제로 적용하는 도구가 아니다.

## 검사 범위

문서·상대 링크·제목 링크·색인 연결, 역할 책임·스킬 형식과 이름, 필수 파일·미치환 값·다른 프로젝트 ID·선택 구성 문서를 확인한다. 코드 블록·인라인 코드의 예시 링크는 제외한다. 지원하지 않는 참조형 링크는 실패로 보고한다.

이미지·모션·소리 제작, 승인, 등록, 실제 게임 연결은 별도 상태다. 자동 검사·에뮬레이터·물리 기기도 별도로 기록한다. 게임 실행 검사는 구현 이후 추가한다.

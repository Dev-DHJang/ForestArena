# 문서 색인

## 처음 읽기

1. [README](../README.md)
2. [제품 방향](product/vision.md)
3. [개발 순서](product/roadmap.md)
4. [현재 운영 상태](operations/harness/operating-index.md)

## 목적별 기준

- 범위·핵심 플레이: [제품 방향](product/vision.md)
- 중요한 선택: [결정 기록](product/decisions.md)
- 코드·데이터 책임: [기술 기준](engineering/architecture.md)
- 자산·출처·승인: [콘텐츠 기준](content/art-and-audio.md)
- 작업 기록과 검사: [작업 절차](operations/ai-development.md)
- 역할과 스킬: [팀 명세](operations/harness/team-spec.md)
- 사전 구성 설명: [독립 지침서](operations/new-game-bootstrap.md)

## 폴더

product는 제품·결정, engineering은 기술·플랫폼, content는 자산 기준, operations는 작업 절차를 담는다. `.agents/skills`는 반복 작업 지침이며 `_workspace`는 요청·마무리 기록이다. 같은 규칙은 한 문서에 쓰고 다른 곳에서는 연결한다.

## 선택 구성

선택한 항목의 준비 문서는 최초 설정 도구가 아래에 연결한다. 선택하지 않은 문서 예시는 `options/`에 보관한다.

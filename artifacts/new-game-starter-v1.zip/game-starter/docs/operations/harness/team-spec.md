# 팀 명세

활성 역할과 스킬 목록의 단일 원본이다. 기본은 단일 에이전트가 아래 책임을 순서대로 맡는다. 역할 분리만으로 여러 에이전트를 실행하지 않는다.

| role-id | 담당 책임 | skill-id |
| --- | --- | --- |
| planning-content | 제품(product), 콘텐츠(content) | starter-game-workflow |
| development | 게임 구현(gameplay), UI(ui), 플랫폼(platform), 공용 데이터(data) | starter-game-workflow |
| review | 품질 확인(qa) | starter-game-workflow |

스킬 경로는 `.agents/skills/<skill-id>/SKILL.md`다. 범위·결정은 planning-content, 작성은 development, 요청 대조·검사는 review가 맡는다. 같은 에이전트의 검사를 독립 검토라고 보고하지 않는다.

Godot 자산·애니메이션·오디오·네트워크 등의 반복 전문 작업이 실제 필요해질 때 스킬을 추가하고 이 표도 갱신한다. 단일 작업 때문에 모든 역할을 분리하지 않는다.

사용자 요청이나 프로젝트 지시가 여러 에이전트 실행을 허용하고 독립 작업의 실익이 분명할 때 담당 파일·환경·통합 담당·부분 실패 처리를 정한다. 같은 파일·기기 작업은 순서대로 하거나 환경을 분리한다.

전달·실패·완료 기록은 [작업 절차](../ai-development.md)를 따른다. 자동 원격 병합은 기본 정책에 포함하지 않는다.

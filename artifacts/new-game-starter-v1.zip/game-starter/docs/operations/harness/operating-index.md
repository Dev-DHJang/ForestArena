# 현재 운영 상태

## 현재 단계

기본 뼈대 준비. 게임별 입력은 미정이며 게임 코드는 없다. 최초 설정 뒤 제품 방향·개발 순서와 이 상태를 맞춘다. 역할 목록은 [팀 명세](team-spec.md) 한 곳에서 관리한다.

## 검사 명령

- 문서: `./scripts/verify-docs.sh`
- 역할·스킬: `./scripts/verify-harness.sh`
- 전체 구조: `./scripts/verify.sh`
- 셸 없이 실행: `python3 tools/verify_bootstrap.py --scope all`
- 입력 적용 완료: `python3 tools/verify_bootstrap.py --scope all --require-configured`

Python 3.9 이상 필요. 실행하지 못하면 환경과 재개 조건을 기록한다. 게임 실행 검사는 구현 이후 추가한다.

## 미확인

엔진 버전·플랫폼·입력·성능·출시 설정은 필요한 것부터 결정한다. 외부 도구는 없음. 도구를 선택하면 필요성·준비 상태·설치나 연결에 필요한 별도 요청·대체 방법을 기록한다.
자동·에뮬레이터·물리 기기 검사는 구현 뒤 각각 환경·날짜·버전·증거와 함께 기록한다. 구조 검사 통과가 게임 실행이나 기기 통과를 뜻하지 않는다.

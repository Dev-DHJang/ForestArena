# 새 게임 작업 안내

- 목적과 현재 범위는 README.md, 문서 위치는 docs/INDEX.md에서 확인한다.
- 쉬운 한국어를 먼저 쓰고 전문 용어는 첫 등장에 뜻을 설명한다.
- 역할과 담당 선택은 docs/operations/harness/team-spec.md 한 곳에서 관리한다.
- 기본은 단일 에이전트이며 역할 구분만으로 다른 에이전트를 실행하지 않는다.
- 기존 결정·사용자 변경을 보존한다. 미정은 proposed(제안)로 기록한다.
- 작업마다 _workspace/<topic>/00_request.md와 04_closeout.md를 남긴다.
- 문서: ./scripts/verify-docs.sh, 역할·스킬: ./scripts/verify-harness.sh, 전체 구조: ./scripts/verify.sh.
- 셸이 없으면 python3 tools/verify_bootstrap.py --scope all을 실행한다.
- 입력 적용 완료는 --require-configured로 확인한다. 게임·기기 실행 통과와 구분한다.
- 설치·계정 연결·원격 작업은 사용자 요청이 있을 때 해당 범위만 진행한다.

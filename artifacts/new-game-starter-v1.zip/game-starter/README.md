# 새 게임

프로젝트 ID: `starter-game` (입력 전 임시 값).

엔진 공통 사전 구성 뼈대다. 엔진·플랫폼·핵심 플레이는 아직 미정이며 게임 코드는 없다. 입력 후 제품 방향을 최종 기준으로 사용한다.

## 시작

[사용 순서](START_HERE.md) → [문서 색인](docs/INDEX.md) → [제품 방향](docs/product/vision.md) → [운영 상태](docs/operations/harness/operating-index.md).

## 검사

Python 3.9 이상으로 `python3 tools/verify_bootstrap.py --scope all`을 실행한다.
macOS·Linux: `./scripts/verify-docs.sh`, `./scripts/verify-harness.sh`, `./scripts/verify.sh`.
입력 적용 완료: `python3 tools/verify_bootstrap.py --scope all --require-configured`.

## 충돌 처리

사용자의 현재 지시와 명시적인 승인 근거를 먼저 확인한다. README·분야 문서·승인 결정이 충돌하면 출처를 기록하고 질문한다. 작업 기록은 승인 결정을 대신하지 않는다.

# Godot 자산 규칙

코드는 논리 자산 ID를 통해 자산을 찾도록 설계한다. 예: ui.confirm. 실제 파일 경로는 assets/resource-registry.json에 기록한다.

등록 목록은 schema_version과 assets 배열을 사용한다. 각 자산은 id, kind, path, variants, production_status, approval_status, source_record 필드를 갖도록 계획한다. 자산이 없으면 배열은 비어 있어도 된다. 없는 파일을 가짜 경로로 등록하지 않는다.

등록 담당·누락 처리·품질별 대체 규칙은 구현 전에 정한다. 실제 사용이 시작되면 ID 중복·파일 누락·잘못된 품질 참조·미등록 ID 사용 검사를 추가한다. 시작 때 자동으로 준비하는 객체(Autoload)는 구현 이후 만든다.

승인·등록·실제 연결·연결 검사는 별도 상태다. 등록됐다고 게임에 연결된 것은 아니다.
